import json
import subprocess
from pathlib import Path


def get_duration(f):
    command = f"ffprobe -v quiet -print_format json -show_format {f}"
    res = json.loads(subprocess.check_output(command, shell=True, text=True))
    return float(res['format']['duration'])


for f in Path.cwd().iterdir():
    if f.suffix in ['.m4a', '.wav']:
        print(f.name, 'duration: ', get_duration(f))
